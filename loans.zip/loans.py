"""
usage: loans -p PRINCIPAL -r RATE -t TERM [-n] [-a]

Calculate loan repayment details.

  -p  Principal (loan amount)
  -r  Annual interest rate in percent (e.g. 5.5 for 5.5%)
  -t  Loan term in years
  -n  Show number of payments only
  -a  Print full amortization schedule
"""

import argparse
import sys
import math

def monthly_payment(principal, annual_rate, years):
    n = years * 12
    if annual_rate == 0:
        return principal / n
    r = annual_rate / 100 / 12
    return principal * r * (1 + r) ** n / ((1 + r) ** n - 1)

def amortization(principal, annual_rate, years):
    n = years * 12
    r = annual_rate / 100 / 12
    payment = monthly_payment(principal, annual_rate, years)
    balance = principal
    rows = []
    for i in range(1, n + 1):
        interest = balance * r
        principal_part = payment - interest
        balance -= principal_part
        if balance < 0:
            balance = 0.0
        rows.append((i, payment, principal_part, interest, balance))
    return rows

def main():
    parser = argparse.ArgumentParser(
        prog='loans',
        description='Loan repayment calculator.'
    )
    parser.add_argument('-p', dest='principal', type=float, required=True,
                        metavar='PRINCIPAL', help='Loan amount.')
    parser.add_argument('-r', dest='rate', type=float, required=True,
                        metavar='RATE', help='Annual interest rate in percent.')
    parser.add_argument('-t', dest='term', type=float, required=True,
                        metavar='TERM', help='Loan term in years.')
    parser.add_argument('-n', dest='payments_only', action='store_true',
                        help='Show number of payments only.')
    parser.add_argument('-a', dest='amort', action='store_true',
                        help='Print full amortization schedule.')
    args = parser.parse_args()

    if args.principal <= 0:
        print('loans: principal must be positive.', file=sys.stderr)
        sys.exit(1)
    if args.rate < 0:
        print('loans: rate cannot be negative.', file=sys.stderr)
        sys.exit(1)
    if args.term <= 0:
        print('loans: term must be positive.', file=sys.stderr)
        sys.exit(1)

    n = int(args.term * 12)
    payment = monthly_payment(args.principal, args.rate, args.term)
    total_paid = payment * n
    total_interest = total_paid - args.principal

    if args.payments_only:
        print('Number of payments: {}'.format(n))
        return

    print('Loan Summary')
    print('------------')
    print('Principal:        ${:,.2f}'.format(args.principal))
    print('Annual rate:       {:.2f}%'.format(args.rate))
    print('Term:              {} years ({} payments)'.format(args.term, n))
    print('Monthly payment:  ${:,.2f}'.format(payment))
    print('Total paid:       ${:,.2f}'.format(total_paid))
    print('Total interest:   ${:,.2f}'.format(total_interest))

    if args.amort:
        print()
        print('{:>4}  {:>12}  {:>12}  {:>12}  {:>12}'.format(
            '#', 'Payment', 'Principal', 'Interest', 'Balance'))
        print('-' * 58)
        for row in amortization(args.principal, args.rate, args.term):
            print('{:>4}  {:>12,.2f}  {:>12,.2f}  {:>12,.2f}  {:>12,.2f}'.format(*row))

if __name__ == '__main__':
    main()
