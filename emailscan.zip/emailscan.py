"""
usage: emailscan [-h] [email ...]
       emailscan -f FILE

Validate one or more email addresses.
"""

import re
import sys
import argparse

EMAIL_RE = re.compile(
    r'^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$'
)

def validate(email):
    return bool(EMAIL_RE.match(email.strip()))

def main():
    parser = argparse.ArgumentParser(
        prog='emailscan',
        description='Validate email addresses.'
    )
    parser.add_argument('emails', metavar='EMAIL', nargs='*',
                        help='Email address(es) to validate.')
    parser.add_argument('-f', '--file', metavar='FILE',
                        help='Read email addresses from a file (one per line).')
    args = parser.parse_args()

    emails = list(args.emails)

    if args.file:
        try:
            with open(args.file) as fh:
                emails += [line.strip() for line in fh if line.strip()]
        except OSError as e:
            print('emailscan: {}: {}'.format(args.file, e.strerror), file=sys.stderr)
            sys.exit(1)

    if not emails:
        parser.print_help()
        sys.exit(0)

    any_invalid = False
    for email in emails:
        ok = validate(email)
        status = 'valid' if ok else 'INVALID'
        print('{}: {}'.format(email, status))
        if not ok:
            any_invalid = True

    sys.exit(1 if any_invalid else 0)

if __name__ == '__main__':
    main()
