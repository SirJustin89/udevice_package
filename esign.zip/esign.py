"""
usage: esign sign   [-o SIGFILE] FILE
       esign verify -s SIGFILE   FILE
       esign sign   -m MESSAGE
       esign verify -s SIGFILE  -m MESSAGE

Create or verify a SHA-256 electronic signature for a file or message.
"""

import hashlib
import sys
import os
import argparse

BLOCK = 65536

def sha256_of_file(path):
    h = hashlib.sha256()
    try:
        with open(path, 'rb') as f:
            while True:
                data = f.read(BLOCK)
                if not data:
                    break
                h.update(data)
    except OSError as e:
        print('esign: {}: {}'.format(path, e.strerror), file=sys.stderr)
        sys.exit(1)
    return h.hexdigest()

def sha256_of_message(msg):
    return hashlib.sha256(msg.encode()).hexdigest()

def cmd_sign(args):
    if args.message:
        digest = sha256_of_message(args.message)
        label = 'message'
    else:
        if not args.file:
            print('esign: provide a FILE or -m MESSAGE to sign.', file=sys.stderr)
            sys.exit(1)
        digest = sha256_of_file(args.file)
        label = args.file

    if args.output:
        try:
            with open(args.output, 'w') as fh:
                fh.write(digest + '\n')
            print('Signature written to {}'.format(args.output))
        except OSError as e:
            print('esign: {}: {}'.format(args.output, e.strerror), file=sys.stderr)
            sys.exit(1)
    else:
        print('SHA-256 ({}) = {}'.format(label, digest))

def cmd_verify(args):
    if not args.sigfile:
        print('esign: -s SIGFILE is required for verify.', file=sys.stderr)
        sys.exit(1)
    try:
        with open(args.sigfile) as fh:
            expected = fh.read().strip()
    except OSError as e:
        print('esign: {}: {}'.format(args.sigfile, e.strerror), file=sys.stderr)
        sys.exit(1)

    if args.message:
        digest = sha256_of_message(args.message)
        label = 'message'
    else:
        if not args.file:
            print('esign: provide a FILE or -m MESSAGE to verify.', file=sys.stderr)
            sys.exit(1)
        digest = sha256_of_file(args.file)
        label = args.file

    if digest == expected:
        print('OK: signature matches ({})'.format(label))
    else:
        print('FAIL: signature does NOT match ({})'.format(label))
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(
        prog='esign',
        description='Create or verify SHA-256 electronic signatures.'
    )
    sub = parser.add_subparsers(dest='command')

    p_sign = sub.add_parser('sign', help='Sign a file or message.')
    p_sign.add_argument('file', metavar='FILE', nargs='?',
                        help='File to sign.')
    p_sign.add_argument('-m', dest='message', metavar='MESSAGE',
                        help='Sign a text message instead of a file.')
    p_sign.add_argument('-o', dest='output', metavar='SIGFILE',
                        help='Write signature to this file.')

    p_verify = sub.add_parser('verify', help='Verify a file or message.')
    p_verify.add_argument('file', metavar='FILE', nargs='?',
                          help='File to verify.')
    p_verify.add_argument('-m', dest='message', metavar='MESSAGE',
                          help='Verify a text message instead of a file.')
    p_verify.add_argument('-s', dest='sigfile', metavar='SIGFILE',
                          required=True, help='Signature file to compare against.')

    args = parser.parse_args()

    if args.command == 'sign':
        cmd_sign(args)
    elif args.command == 'verify':
        cmd_verify(args)
    else:
        parser.print_help()

if __name__ == '__main__':
    main()
