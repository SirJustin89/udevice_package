"""
usage: mailfilter [-h] [-d SIGFILE] [-v] FILE [FILE ...]
       mailfilter [-h] [-d SIGFILE] [-v] -

Scan email files (.eml or plain text) exported from the iOS Mail app or
Gmail for:
  1. Spam / phishing indicators  (fake sender, urgent language, link traps)
  2. Valid e-document signature   (SHA-256 check — requires -d SIGFILE)
  3. Legitimate loan / lender content  (known lender keywords vs. loan spam)

Each email is given one of three verdicts:
  [LEGITIMATE]  Passes all checks — no spam indicators found.
  [REVIEW]      Some suspicious signals but also legitimate markers.
  [SPAM]        Strong spam / phishing signals detected.

Options:
  -d SIGFILE   SHA-256 signature file to verify the email body against.
  -v           Verbose — show all scored signals.
  -            Read a single email from stdin instead of a file.

Examples:
  mailfilter email1.eml email2.eml
  mailfilter -v -d contract.sig loan_offer.txt
  cat message.eml | mailfilter -
"""

import re
import sys
import os
import hashlib
import argparse
from datetime import datetime

# ══════════════════════════════════════════════════════════════════════════════
# Signal databases
# ══════════════════════════════════════════════════════════════════════════════

# Spam / phishing signals (regex, score, label)
SPAM_SIGNALS = [
    (r'urgent[ly]*\b',                      2, 'urgency language'),
    (r'act\s+now\b',                         2, 'act-now pressure'),
    (r'limited\s+time\s+offer',              2, 'limited-time pressure'),
    (r'click\s+here\b',                      2, 'click-here link'),
    (r'you\s+have\s+won\b',                  4, 'prize/lottery claim'),
    (r'congratulations.*won',                4, 'prize/lottery claim'),
    (r'verify\s+your\s+account',             2, 'account-verify phish'),
    (r'confirm\s+your\s+(password|login)',   3, 'credential phish'),
    (r'nigerian?\b',                         3, 'advance-fee fraud'),
    (r'prince\b.*\$',                        4, 'advance-fee fraud'),
    (r'wire\s+transfer',                     2, 'wire-transfer request'),
    (r'western\s+union\b',                   3, 'untraceable payment'),
    (r'moneygram\b',                         3, 'untraceable payment'),
    (r'gift\s+card\s+payment',               4, 'gift-card scam'),
    (r'100\s*%\s*(free|approved|guaranteed)',3, 'guaranteed-approval bait'),
    (r'no\s+credit\s+check\b',               2, 'no-credit-check bait'),
    (r'pre[\-\s]?approved\b',                1, 'pre-approved bait'),
    (r'dear\s+(friend|sir|madam)\b',         1, 'generic salutation'),
    (r'undisclosed[\-\s]?recipient',         2, 'mass-email header'),
    (r'unsubscribe\s+here\b',                1, 'bulk-email footer'),
    (r'http://\S+',                          1, 'plain HTTP link (not HTTPS)'),
    (r'bit\.ly|tinyurl|t\.co/',             2, 'shortened/obfuscated URL'),
    (r'your\s+(ssn|social\s+security)',      4, 'SSN solicitation'),
    (r'bank\s+account\s+number',             3, 'account-number solicitation'),
]

# Legitimate loan / lender signals (regex, score, label)
LENDER_SIGNALS = [
    (r'\bapr\b',                             2, 'APR disclosure'),
    (r'annual\s+percentage\s+rate',          2, 'APR disclosure'),
    (r'equal\s+housing\s+(lender|opportunity)',3,'regulated lender disclosure'),
    (r'nmls\b',                              3, 'NMLS license number'),
    (r'fdic\b',                              3, 'FDIC-insured'),
    (r'ncua\b',                              2, 'NCUA-insured credit union'),
    (r'truth\s+in\s+lending',                3, 'TILA disclosure'),
    (r'loan\s+estimate\b',                   2, 'official loan estimate'),
    (r'good\s+faith\s+estimate',             2, 'GFE disclosure'),
    (r'closing\s+disclosure',                2, 'official closing doc'),
    (r'fixed[\-\s]?rate\s+mortgage',         1, 'mortgage product'),
    (r'adjustable[\-\s]?rate\s+mortgage',    1, 'ARM product'),
    (r'refinanc',                            1, 'refinance mention'),
    (r'heloc\b',                             1, 'HELOC product'),
    (r'debt[\-\s]?to[\-\s]?income',          2, 'DTI disclosure'),
    (r'credit\s+score\s+required',           2, 'credit criteria disclosed'),
    (r'origination\s+fee',                   2, 'fee transparency'),
    (r'no\s+prepayment\s+penalty',           1, 'borrower-friendly term'),
]

# Known legitimate lender domain fragments (partial match)
KNOWN_LENDERS = [
    'chase.com', 'bankofamerica.com', 'wellsfargo.com', 'usbank.com',
    'citibank.com', 'discover.com', 'capitalone.com', 'sofi.com',
    'lendingclub.com', 'prosper.com', 'sba.gov', 'hud.gov',
    'freddiemac.com', 'fanniemae.com', 'quickenloans.com', 'rocketmortgage.com',
    'navyfederal.org', 'penfed.org', 'ally.com', 'synchrony.com',
]

# Valid e-document related keywords
EDOC_KEYWORDS = [
    r'sha[\-\s]?256', r'digital\s+signature', r'e[\-\s]?sign',
    r'docusign', r'adobe\s+sign', r'hellofax', r'signed\s+document',
    r'notarized', r'certificate\s+of\s+(authenticity|origin)',
]

# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def score_text(text, signals):
    """Return (total_score, [(label, score), ...])."""
    low = text.lower()
    total = 0
    hits  = []
    for pattern, weight, label in signals:
        if re.search(pattern, low):
            total += weight
            hits.append((label, weight))
    return total, hits

def sha256_text(text):
    return hashlib.sha256(text.encode('utf-8', errors='replace')).hexdigest()

def load_sig(path):
    try:
        with open(path) as f:
            return f.read().strip()
    except OSError as e:
        return None, str(e)

def known_lender_in_text(text):
    low = text.lower()
    for domain in KNOWN_LENDERS:
        if domain in low:
            return domain
    return None

def edoc_present(text):
    low = text.lower()
    for pat in EDOC_KEYWORDS:
        if re.search(pat, low):
            return True
    return False

def verdict(spam_score, lender_score, sig_ok, has_edoc):
    """Return (verdict_str, colour_hint)."""
    if spam_score >= 8:
        return 'SPAM', 'high'
    if spam_score >= 4 and lender_score < 4:
        return 'SPAM', 'medium'
    if lender_score >= 4 or sig_ok or (lender_score >= 2 and spam_score <= 2):
        return 'LEGITIMATE', 'none'
    if spam_score >= 2:
        return 'REVIEW', 'low'
    return 'LEGITIMATE', 'none'

# ══════════════════════════════════════════════════════════════════════════════
# Per-file scan
# ══════════════════════════════════════════════════════════════════════════════

def scan_email(name, text, sig_expected, verbose):
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    spam_score,   spam_hits   = score_text(text, SPAM_SIGNALS)
    lender_score, lender_hits = score_text(text, LENDER_SIGNALS)
    lender_domain              = known_lender_in_text(text)
    has_edoc                   = edoc_present(text)

    # Signature check
    sig_ok     = False
    sig_status = 'skipped'
    if sig_expected:
        actual = sha256_text(text)
        if actual == sig_expected:
            sig_ok     = True
            sig_status = 'VERIFIED'
        else:
            sig_status = 'MISMATCH'

    verd, _ = verdict(spam_score, lender_score, sig_ok, has_edoc)

    sep = '─' * 60
    print(sep)
    print('  File     : {}'.format(name))
    print('  Scanned  : {}'.format(now))
    print('  Verdict  : [{}]'.format(verd))
    print('  Spam score   : {}  |  Lender score : {}'.format(spam_score, lender_score))
    if lender_domain:
        print('  Known lender : {}'.format(lender_domain))
    print('  E-document   : {}  |  Signature : {}'.format(
        'present' if has_edoc else 'none', sig_status))

    if verbose:
        if spam_hits:
            print()
            print('  Spam signals detected:')
            for label, w in spam_hits:
                print('    [-{:2d}]  {}'.format(w, label))
        if lender_hits:
            print()
            print('  Legitimate lender signals:')
            for label, w in lender_hits:
                print('    [+{:2d}]  {}'.format(w, label))

    return verd

# ══════════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        prog='mailfilter',
        description='Scan email files for spam, e-documents, and legitimate loans.'
    )
    parser.add_argument('files', metavar='FILE', nargs='*',
                        help='Email file(s) to scan (.eml or plain text). '
                             'Use - to read from stdin.')
    parser.add_argument('-d', dest='sigfile', default=None, metavar='SIGFILE',
                        help='SHA-256 signature file to verify email body against.')
    parser.add_argument('-v', dest='verbose', action='store_true',
                        help='Verbose — show all scored signals.')
    args = parser.parse_args()

    if not args.files:
        parser.print_help()
        sys.exit(0)

    # Load expected signature once
    sig_expected = None
    if args.sigfile:
        try:
            with open(args.sigfile) as f:
                sig_expected = f.read().strip()
        except OSError as e:
            print('mailfilter: {}: {}'.format(args.sigfile, e.strerror),
                  file=sys.stderr)
            sys.exit(1)

    total = len(args.files)
    counts = {'LEGITIMATE': 0, 'REVIEW': 0, 'SPAM': 0}

    start = datetime.now()
    print('═' * 60)
    print('  mailfilter  —  {}'.format(start.strftime('%Y-%m-%d %H:%M:%S')))
    print('  Emails to scan: {}'.format(total))
    print('═' * 60)

    for idx, fname in enumerate(args.files, 1):
        pct = idx / total * 100
        print()
        print('  [{}/{}]  {:.0f}% complete'.format(idx, total, pct))

        if fname == '-':
            text = sys.stdin.read()
            name = '<stdin>'
        else:
            try:
                with open(fname, encoding='utf-8', errors='replace') as f:
                    text = f.read()
                name = os.path.basename(fname)
            except OSError as e:
                print('mailfilter: {}: {}'.format(fname, e.strerror),
                      file=sys.stderr)
                counts['SPAM'] += 1   # unreadable file = treat as unsafe
                continue

        verd = scan_email(name, text, sig_expected, args.verbose)
        counts[verd] += 1

    end = datetime.now()
    elapsed = (end - start).total_seconds()

    print()
    print('═' * 60)
    print('  Scan complete  —  {}'.format(end.strftime('%Y-%m-%d %H:%M:%S')))
    print('  Elapsed: {:.2f}s'.format(elapsed))
    print()
    print('  LEGITIMATE : {}'.format(counts['LEGITIMATE']))
    print('  REVIEW     : {}'.format(counts['REVIEW']))
    print('  SPAM       : {}'.format(counts['SPAM']))
    print('═' * 60)

    sys.exit(0 if counts['SPAM'] == 0 and counts['REVIEW'] == 0 else 1)


if __name__ == '__main__':
    main()
