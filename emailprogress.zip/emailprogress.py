"""
usage: emailprogress [-h] [-d DELAY] [EMAIL ...]

Scan and validate email addresses with a live progress display showing
the current date/time and percentage to completion.

If no addresses are supplied the built-in list of 5 addresses is used:
    si*********@outlook.com
    si*****@live.com
    si******************@outlook.com
    ub********@gmail.com
    si*********@gmail.com

Options:
  -d DELAY   Seconds to pause between each scan step (default: 0.3)
  -f FILE    Read additional addresses from a file (one per line)
  -q         Quiet — suppress the progress bar, show only the summary
"""

import re
import sys
import time
import argparse
from datetime import datetime

# ── email validation ──────────────────────────────────────────────────────────
EMAIL_RE = re.compile(r'^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$')

def validate(addr):
    return bool(EMAIL_RE.match(addr.strip()))

# ── email masking ─────────────────────────────────────────────────────────────
def mask_email(addr):
    """Return a masked version of addr: first 2 chars of local part + asterisks + @domain."""
    local, _, domain = addr.partition('@')
    if not domain:
        return addr
    visible = min(2, len(local))
    masked = local[:visible] + '*' * (len(local) - visible)
    return '{}@{}'.format(masked, domain)

# ── default addresses ─────────────────────────────────────────────────────────
DEFAULT_EMAILS = [
    'sirlevering@outlook.com',
    'sir1310@live.com',
    'sirjustin.levering57@outlook.com',
    'ubntknight@gmail.com',
    'sirlevering@gmail.com',
]

# ── progress bar ──────────────────────────────────────────────────────────────
BAR_WIDTH = 30

def draw_bar(done, total):
    pct  = done / total
    fill = int(BAR_WIDTH * pct)
    bar  = '#' * fill + '-' * (BAR_WIDTH - fill)
    return '[{}] {:5.1f}%'.format(bar, pct * 100)

# ── main ──────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        prog='emailprogress',
        description='Scan email addresses with date/time progress display.'
    )
    parser.add_argument('emails', metavar='EMAIL', nargs='*',
                        help='Email address(es) to scan (default: built-in list).')
    parser.add_argument('-d', dest='delay', type=float, default=0.3,
                        metavar='DELAY',
                        help='Pause between steps in seconds (default: 0.3).')
    parser.add_argument('-f', dest='file', default=None, metavar='FILE',
                        help='Read addresses from a file (one per line).')
    parser.add_argument('-q', dest='quiet', action='store_true',
                        help='Suppress progress bar; show summary only.')
    args = parser.parse_args()

    emails = list(args.emails)

    if args.file:
        try:
            with open(args.file) as fh:
                emails += [l.strip() for l in fh if l.strip()]
        except OSError as e:
            print('emailprogress: {}: {}'.format(args.file, e.strerror),
                  file=sys.stderr)
            sys.exit(1)

    if not emails:
        emails = DEFAULT_EMAILS[:]

    total   = len(emails)
    results = []

    start_dt = datetime.now()
    start_ts = time.time()

    sep = '=' * 60
    print(sep)
    print('  Email Scan — Started {}'.format(
        start_dt.strftime('%Y-%m-%d  %H:%M:%S')))
    print('  Addresses to scan: {}'.format(total))
    print(sep)

    for idx, addr in enumerate(emails, start=1):
        step_dt = datetime.now()

        ok     = validate(addr)
        status = 'VALID  ' if ok else 'INVALID'
        results.append((addr, ok))

        pct_done = idx / total * 100
        bar_str  = draw_bar(idx, total)

        if not args.quiet:
            ts = step_dt.strftime('%Y-%m-%d %H:%M:%S')
            print('[{}]  {:5.1f}%  {}  {}  {}'.format(
                ts, pct_done, bar_str, status, mask_email(addr)))

        time.sleep(args.delay)

    end_dt = datetime.now()
    elapsed = time.time() - start_ts

    # ── summary ───────────────────────────────────────────────────────────────
    valid_list   = [a for a, ok in results if ok]
    invalid_list = [a for a, ok in results if not ok]

    print()
    print(sep)
    print('  Scan Complete — {}'.format(end_dt.strftime('%Y-%m-%d  %H:%M:%S')))
    print('  Elapsed: {:.2f}s   Scanned: {}   Valid: {}   Invalid: {}'.format(
        elapsed, total, len(valid_list), len(invalid_list)))
    print(sep)

    if valid_list:
        print()
        print('  VALID ({})'.format(len(valid_list)))
        for a in valid_list:
            print('    [OK]  {}'.format(mask_email(a)))

    if invalid_list:
        print()
        print('  INVALID ({})'.format(len(invalid_list)))
        for a in invalid_list:
            print('    [!!]  {}'.format(mask_email(a)))

    print()
    sys.exit(0 if not invalid_list else 1)


if __name__ == '__main__':
    main()
