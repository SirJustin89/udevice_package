"""
usage: mailworkflow EMAIL1 EMAIL2 EMAIL3
                    [-l LOAN_AMOUNT] [-r RATE] [-t TERM]
                    [-d DOCUMENT] [-s SIGFILE]

Scan exactly 3 email addresses, validate a loan, and verify an
e-document signature.  For each address that passes all checks, the
recommended iOS Mail action is printed as  [VIP].  Any address that
fails is printed as  [ARCHIVE].

Steps performed for each address:
  1. Email address format validation
  2. Loan validation  (principal > 0, rate >= 0, term > 0)
  3. E-document SHA-256 signature verification (if -d and -s are given)

Flags:
  -l  Loan principal amount         (default: 0 — skips loan check)
  -r  Annual interest rate (%)      (default: 0)
  -t  Loan term in years            (default: 0 — skips loan check)
  -d  Document file to verify       (skipped if not provided)
  -s  SHA-256 signature file        (required when -d is used)
  -v  Verbose output
"""

import re
import sys
import hashlib
import argparse

# ── email validation ──────────────────────────────────────────────────────────
EMAIL_RE = re.compile(r'^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$')

def validate_email(addr):
    return bool(EMAIL_RE.match(addr.strip()))

# ── loan validation ───────────────────────────────────────────────────────────
def validate_loan(principal, rate, term):
    """Return (ok, reason). ok=True means the loan parameters are valid."""
    if principal <= 0:
        return False, 'principal must be > 0 (got {})'.format(principal)
    if rate < 0:
        return False, 'rate must be >= 0 (got {})'.format(rate)
    if term <= 0:
        return False, 'term must be > 0 (got {})'.format(term)
    n = int(term * 12)
    r = rate / 100 / 12
    if r == 0:
        monthly = principal / n
    else:
        monthly = principal * r * (1 + r) ** n / ((1 + r) ** n - 1)
    total = monthly * n
    interest = total - principal
    return True, 'monthly=${:.2f}  total=${:.2f}  interest=${:.2f}'.format(
        monthly, total, interest)

# ── e-document verification ───────────────────────────────────────────────────
BLOCK = 65536

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        while True:
            data = f.read(BLOCK)
            if not data:
                break
            h.update(data)
    return h.hexdigest()

def verify_document(doc_path, sig_path):
    """Return (ok, reason)."""
    try:
        actual = sha256_file(doc_path)
    except OSError as e:
        return False, 'cannot read document: {}'.format(e.strerror)
    try:
        with open(sig_path) as fh:
            expected = fh.read().strip()
    except OSError as e:
        return False, 'cannot read signature file: {}'.format(e.strerror)
    if actual == expected:
        return True, 'SHA-256 matches'
    return False, 'SHA-256 mismatch (got {}, expected {})'.format(actual, expected)

# ── main ──────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        prog='mailworkflow',
        description='Scan 3 emails, validate loan & e-document, output VIP or Archive.'
    )
    parser.add_argument('emails', metavar='EMAIL', nargs=3,
                        help='Exactly 3 email addresses to process.')
    parser.add_argument('-l', dest='principal', type=float, default=0.0,
                        metavar='AMOUNT', help='Loan principal (0 = skip loan check).')
    parser.add_argument('-r', dest='rate', type=float, default=0.0,
                        metavar='RATE',   help='Annual interest rate in %% (default 0).')
    parser.add_argument('-t', dest='term', type=float, default=0.0,
                        metavar='TERM',   help='Loan term in years (0 = skip loan check).')
    parser.add_argument('-d', dest='document', default=None,
                        metavar='FILE',   help='Document file to verify.')
    parser.add_argument('-s', dest='sigfile', default=None,
                        metavar='SIGFILE', help='Signature file for -d.')
    parser.add_argument('-v', dest='verbose', action='store_true',
                        help='Verbose output.')
    args = parser.parse_args()

    check_loan = args.principal > 0 and args.term > 0
    check_doc  = args.document is not None

    if check_doc and not args.sigfile:
        parser.error('-s SIGFILE is required when -d DOCUMENT is provided.')

    # ── run shared checks once ────────────────────────────────────────────────
    loan_ok, loan_msg = True, '(skipped)'
    if check_loan:
        loan_ok, loan_msg = validate_loan(args.principal, args.rate, args.term)

    doc_ok, doc_msg = True, '(skipped)'
    if check_doc:
        doc_ok, doc_msg = verify_document(args.document, args.sigfile)

    # ── print shared check results ────────────────────────────────────────────
    sep = '=' * 56
    print(sep)
    print('  Mail Workflow Report')
    print(sep)

    if check_loan:
        loan_status = 'VALID' if loan_ok else 'INVALID'
        print('Loan check   : [{}] {}'.format(loan_status, loan_msg))
    else:
        print('Loan check   : (skipped — use -l, -r, -t to enable)')

    if check_doc:
        doc_status = 'VERIFIED' if doc_ok else 'FAILED'
        print('E-doc check  : [{}] {}'.format(doc_status, doc_msg))
    else:
        print('E-doc check  : (skipped — use -d and -s to enable)')

    print()
    print('Addresses processed: {}'.format(len(args.emails)))
    print('-' * 56)

    # ── per-address evaluation ────────────────────────────────────────────────
    all_pass = loan_ok and doc_ok

    results = []
    for addr in args.emails:
        addr = addr.strip()
        email_ok = validate_email(addr)
        passed   = email_ok and all_pass

        checks = []
        checks.append('email={}'.format('OK' if email_ok else 'INVALID'))
        if check_loan:
            checks.append('loan={}'.format('OK' if loan_ok else 'FAIL'))
        if check_doc:
            checks.append('edoc={}'.format('OK' if doc_ok else 'FAIL'))

        action = '[VIP]    ' if passed else '[ARCHIVE]'
        results.append((addr, action, checks))

        detail = '  ({})'.format(', '.join(checks)) if args.verbose else ''
        print('{} {}{}'.format(action, addr, detail))

    print('-' * 56)
    vip_count     = sum(1 for _, a, _ in results if 'VIP' in a)
    archive_count = sum(1 for _, a, _ in results if 'ARCHIVE' in a)
    print('VIP: {}   Archive: {}'.format(vip_count, archive_count))
    print(sep)

    # ── iOS Mail app instructions ─────────────────────────────────────────────
    vip_list     = [addr for addr, a, _ in results if 'VIP' in a]
    archive_list = [addr for addr, a, _ in results if 'ARCHIVE' in a]

    if vip_list or archive_list:
        print()
        print('iOS Mail app actions:')
        if vip_list:
            print()
            print('  Label as VIP:')
            for addr in vip_list:
                print('    1. Open Mail  →  Tap sender "{}"'.format(addr))
                print('       2. Tap the sender\'s name/photo at the top of the email')
                print('       3. Tap "Add to VIP"')
        if archive_list:
            print()
            print('  Archive:')
            for addr in archive_list:
                print('    1. Open Mail  →  Find email from "{}"'.format(addr))
                print('       2. Swipe left on the message')
                print('       3. Tap "Archive"  (or "More" → "Archive")')

    sys.exit(0 if archive_count == 0 else 1)


if __name__ == '__main__':
    main()
