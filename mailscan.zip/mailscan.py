"""
usage: mailscan [-h] [-p PORT] [-t TIMEOUT] [--ssl] HOST
       mailscan --smtp [-p PORT] [-t TIMEOUT] [--ssl] HOST

Scan a mail server and report its supported features/capabilities.

Default mode scans IMAP (port 143 / 993 with --ssl).
Use --smtp to scan an SMTP server (port 25 / 465 with --ssl, or 587).

Examples:
    mailscan imap.gmail.com
    mailscan --ssl imap.gmail.com
    mailscan --smtp smtp.gmail.com
    mailscan --smtp --ssl -p 465 smtp.gmail.com
"""

import imaplib
import smtplib
import argparse
import socket
import sys

DEFAULT_IMAP_PORT = 993
DEFAULT_IMAP_PORT_PLAIN = 143
DEFAULT_SMTP_PORT = 587
DEFAULT_SMTP_PORT_SSL = 465


def scan_imap(host, port, use_ssl, timeout):
    print('Scanning IMAP server: {}:{} (ssl={})'.format(host, port, use_ssl))
    print()
    try:
        if use_ssl:
            conn = imaplib.IMAP4_SSL(host, port)
        else:
            conn = imaplib.IMAP4(host, port)
    except (OSError, imaplib.IMAP4.error) as e:
        print('Error connecting: {}'.format(e), file=sys.stderr)
        sys.exit(1)

    # Server greeting / welcome
    print('Server greeting : {}'.format(conn.welcome.decode(errors='replace')))

    # Capabilities
    try:
        typ, data = conn.capability()
        if typ == 'OK' and data and data[0]:
            caps = data[0].decode(errors='replace').split()
            print()
            print('Capabilities ({} reported):'.format(len(caps)))
            for cap in sorted(caps):
                print('  {}'.format(cap))
        else:
            print('Capabilities: (none reported)')
    except Exception as e:
        print('Could not retrieve capabilities: {}'.format(e))

    conn.logout()


def scan_smtp(host, port, use_ssl, timeout):
    print('Scanning SMTP server: {}:{} (ssl={})'.format(host, port, use_ssl))
    print()
    try:
        if use_ssl:
            conn = smtplib.SMTP_SSL(host, port, timeout=timeout)
        else:
            conn = smtplib.SMTP(host, port, timeout=timeout)
    except (OSError, smtplib.SMTPException) as e:
        print('Error connecting: {}'.format(e), file=sys.stderr)
        sys.exit(1)

    # EHLO to get features
    try:
        code, msg = conn.ehlo()
        banner = msg.decode(errors='replace').split('\n')[0].strip()
        print('Server banner   : {} (code {})'.format(banner, code))
    except Exception as e:
        print('EHLO failed: {}'.format(e))
        conn.quit()
        return

    esmtp_features = conn.esmtp_features
    if esmtp_features:
        print()
        print('ESMTP features ({} reported):'.format(len(esmtp_features)))
        for name in sorted(esmtp_features):
            val = esmtp_features[name]
            if val:
                print('  {:20s} {}'.format(name.upper(), val))
            else:
                print('  {}'.format(name.upper()))
    else:
        print('ESMTP features: (none reported)')

    # Check STARTTLS availability
    if not use_ssl:
        print()
        if conn.has_extn('starttls'):
            print('STARTTLS: supported')
        else:
            print('STARTTLS: not advertised')

    conn.quit()


def main():
    parser = argparse.ArgumentParser(
        prog='mailscan',
        description='Scan a mail server and list its supported features.'
    )
    parser.add_argument('host', metavar='HOST',
                        help='Mail server hostname or IP address.')
    parser.add_argument('-p', dest='port', type=int, default=None,
                        metavar='PORT', help='Port number (overrides default).')
    parser.add_argument('--ssl', action='store_true',
                        help='Use SSL/TLS connection.')
    parser.add_argument('--smtp', action='store_true',
                        help='Scan SMTP instead of IMAP.')
    parser.add_argument('-t', dest='timeout', type=float, default=10.0,
                        metavar='TIMEOUT', help='Connection timeout in seconds (default: 10).')
    args = parser.parse_args()

    # Resolve hostname first to give a clear error
    try:
        ip = socket.gethostbyname(args.host)
        print('Host: {} ({})'.format(args.host, ip))
    except socket.gaierror as e:
        print('mailscan: {}: {}'.format(args.host, e), file=sys.stderr)
        sys.exit(1)

    socket.setdefaulttimeout(args.timeout)

    if args.smtp:
        if args.port is None:
            port = DEFAULT_SMTP_PORT_SSL if args.ssl else DEFAULT_SMTP_PORT
        else:
            port = args.port
        scan_smtp(args.host, port, args.ssl, args.timeout)
    else:
        if args.port is None:
            port = DEFAULT_IMAP_PORT if args.ssl else DEFAULT_IMAP_PORT_PLAIN
        else:
            port = args.port
        scan_imap(args.host, port, args.ssl, args.timeout)


if __name__ == '__main__':
    main()
