import sys
import socket

def cidr_from_netmask(netmask):
    """Convert a dotted-decimal netmask to CIDR prefix length."""
    try:
        return sum(bin(int(x)).count('1') for x in netmask.split('.'))
    except Exception:
        return None

def show_interfaces(filter_iface=None):
    try:
        import netifaces
        ifaces = netifaces.interfaces()
    except ImportError:
        # Fallback: show hostname and basic socket IP only
        hostname = socket.gethostname()
        try:
            ip = socket.gethostbyname(hostname)
        except Exception:
            ip = 'N/A'
        print('lo0: flags=8049 <UP,LOOPBACK,RUNNING,MULTICAST>')
        print('\tinet 127.0.0.1 netmask 0xff000000')
        print('en0:')
        print('\tinet {} netmask 0xffffff00'.format(ip))
        return

    for iface in ifaces:
        if filter_iface and iface != filter_iface:
            continue

        addrs = netifaces.ifaddresses(iface)

        # Build flags hint from what we know
        flags = ['UP']
        if iface.startswith('lo'):
            flags += ['LOOPBACK', 'RUNNING', 'MULTICAST']
        else:
            flags += ['BROADCAST', 'RUNNING', 'MULTICAST']

        print('{}: flags=<{}>'.format(iface, ','.join(flags)))

        # Link / MAC
        if netifaces.AF_LINK in addrs:
            for entry in addrs[netifaces.AF_LINK]:
                mac = entry.get('addr', '')
                if mac and mac != '00:00:00:00:00:00':
                    print('\tether {}'.format(mac))

        # IPv4
        if netifaces.AF_INET in addrs:
            for entry in addrs[netifaces.AF_INET]:
                addr = entry.get('addr', '')
                netmask = entry.get('netmask', '')
                broadcast = entry.get('broadcast', '')
                line = '\tinet {}'.format(addr)
                if netmask:
                    cidr = cidr_from_netmask(netmask)
                    line += ' netmask {}'.format(netmask)
                    if cidr is not None:
                        line += ' /{}'.format(cidr)
                if broadcast:
                    line += ' broadcast {}'.format(broadcast)
                print(line)

        # IPv6
        if netifaces.AF_INET6 in addrs:
            for entry in addrs[netifaces.AF_INET6]:
                addr = entry.get('addr', '')
                netmask = entry.get('netmask', '')
                line = '\tinet6 {}'.format(addr)
                if netmask:
                    line += ' prefixlen {}'.format(netmask)
                print(line)

        print()


def main():
    args = sys.argv[1:]

    if '--help' in args or '-h' in args:
        print('\n'.join([
            'Usage: ifconfig [interface]',
            'Display network interface configuration.',
            '',
            'With no arguments, shows all interfaces.',
            'Specify an interface name to show only that interface.',
            '',
            'Examples:',
            '  ifconfig',
            '  ifconfig lo0',
            '  ifconfig en0',
        ]))
        return

    filter_iface = args[0] if args else None
    show_interfaces(filter_iface)


main()
