import sys

def main():
    args = sys.argv[1:]

    if '--help' in args:
        print('\n'.join([
            'Usage: tee [-a] [FILE...]',
            'Read from standard input and write to standard output and files.',
            '',
            'Options:',
            '  -a    Append to the given files instead of overwriting them',
            '',
            'Examples:',
            '  ls | tee output.txt',
            '  ls | tee -a log.txt',
            '  ls | tee -a a.txt b.txt c.txt',
        ]))
        sys.exit(0)

    append = False
    if '-a' in args:
        append = True
        args.remove('-a')

    mode = 'a' if append else 'w'

    files = []
    try:
        for path in args:
            files.append(open(path, mode))

        for line in sys.stdin:
            sys.stdout.write(line)
            sys.stdout.flush()
            for f in files:
                f.write(line)
    finally:
        for f in files:
            f.close()

main()
